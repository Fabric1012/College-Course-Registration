<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}
require_once 'Database.php';
$db = (new Database())->connect();
$studentId = (int) $_SESSION['student_id'];
$message = '';

// Add or drop a class when a button is clicked.
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $courseId = (int) ($_POST['course_id'] ?? 0);
    $action = $_POST['action'] ?? '';
    if ($courseId > 0 && $action == 'add') {
        // Only add real classes, and never add the same class twice.
        $sql = 'INSERT IGNORE INTO enrollments (student_id, course_id)
                SELECT ?, id FROM courses WHERE id = ?';
        $stmt = $db->prepare($sql);
        $stmt->bind_param('ii', $studentId, $courseId);
        $stmt->execute();
        $message = $stmt->affected_rows ? 'Class added!' : 'You already have this class.';
    } elseif ($courseId > 0 && $action == 'drop') {
        $stmt = $db->prepare('DELETE FROM enrollments WHERE student_id = ? AND course_id = ?');
        $stmt->bind_param('ii', $studentId, $courseId);
        $stmt->execute();
        $message = 'Class removed.';
    }
}

// Show classes for the semester the student selects.
$semester = $_GET['semester'] ?? $_POST['semester'] ?? 'Spring';
if (!in_array($semester, ['Spring', 'Summer', 'Fall'])) $semester = 'Spring';
$stmt = $db->prepare('SELECT id, code, title FROM courses WHERE semester = ? ORDER BY code');
$stmt->bind_param('s', $semester);
$stmt->execute();
$available = $stmt->get_result();

$stmt2 = $db->prepare('SELECT courses.id, courses.code, courses.title
    FROM courses JOIN enrollments ON courses.id = enrollments.course_id
    WHERE enrollments.student_id = ? AND courses.semester = ? ORDER BY courses.code');
$stmt2->bind_param('is', $studentId, $semester);
$stmt2->execute();
$registered = $stmt2->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Classes</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-5" style="max-width:750px">
    <h1>My Classes</h1>
    <p><a href="profile.php">Profile</a> | <a href="logout.php">Logout</a></p>
    <p><?php echo htmlspecialchars($message); ?></p>
    <form method="get">
        <label>Semester</label>
        <select name="semester" onchange="this.form.submit()">
            <?php foreach (['Spring', 'Summer', 'Fall'] as $term) { ?>
                <option value="<?php echo $term; ?>" <?php if ($term == $semester) echo 'selected'; ?>><?php echo $term; ?></option>
            <?php } ?>
        </select>
    </form>
    <h2 class="mt-4">Available Classes</h2>
    <?php while ($course = $available->fetch_assoc()) { ?>
        <div class="mb-2">
            <?php echo htmlspecialchars($course['code'] . ' - ' . $course['title']); ?>
            <form method="post" style="display:inline">
                <input type="hidden" name="semester" value="<?php echo $semester; ?>">
                <input type="hidden" name="course_id" value="<?php echo $course['id']; ?>">
                <input type="hidden" name="action" value="add">
                <button class="btn btn-sm btn-success">Add</button>
            </form>
        </div>
    <?php } ?>
    <h2 class="mt-4">My Schedule</h2>
    <?php if ($registered->num_rows == 0) echo '<p>No classes yet.</p>'; ?>
    <?php while ($course = $registered->fetch_assoc()) { ?>
        <div class="mb-2">
            <?php echo htmlspecialchars($course['code'] . ' - ' . $course['title']); ?>
            <form method="post" style="display:inline">
                <input type="hidden" name="semester" value="<?php echo $semester; ?>">
                <input type="hidden" name="course_id" value="<?php echo $course['id']; ?>">
                <input type="hidden" name="action" value="drop">
                <button class="btn btn-sm btn-danger">Drop</button>
            </form>
        </div>
    <?php } ?>
</div>
</body>
</html>
