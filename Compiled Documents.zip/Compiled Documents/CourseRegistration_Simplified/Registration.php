<?php
require_once 'Database.php';
$message = '';

// This runs when the student clicks Register.
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $studentId = trim($_POST['student_id'] ?? '');
    $firstName = trim($_POST['first_name'] ?? '');
    $lastName = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($studentId == '' || $firstName == '' || $lastName == '' ||
        $email == '' || $phone == '' || $username == '' || $password == '') {
        $message = 'Please fill out every field.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Please enter a valid email.';
    } elseif (strlen($password) < 8) {
        $message = 'Password must be at least 8 characters.';
    } else {
        $database = new Database();
        $connection = $database->connect();

        // Save a protected version of the password, not the real password.
        $safePassword = password_hash($password, PASSWORD_DEFAULT);

        // Question marks protect the database from unsafe input.
        $sql = 'INSERT INTO students (student_id, first_name, last_name, email, phone, username, password_hash) VALUES (?, ?, ?, ?, ?, ?, ?)';
        $statement = $connection->prepare($sql);
        $statement->bind_param('sssssss', $studentId, $firstName, $lastName, $email, $phone, $username, $safePassword);

        try {
            $statement->execute();
            $message = 'Account created! You can log in now.';
        } catch (mysqli_sql_exception $error) {
            if ($error->getCode() == 1062) {
                $message = 'Student ID, email, or username is already used.';
            } else {
                $message = 'Could not create account. Please try again.';
                error_log($error->getMessage());
            }
        }
        $statement->close();
        $connection->close();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Registration</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-5" style="max-width: 500px;">
    <h1>Student Registration</h1>
    <p><?php echo htmlspecialchars($message); ?></p>
    <form method="post">
        <label>Student ID</label>
        <input class="form-control mb-2" name="student_id" required>
        <label>First Name</label>
        <input class="form-control mb-2" name="first_name" required>
        <label>Last Name</label>
        <input class="form-control mb-2" name="last_name" required>
        <label>Email</label>
        <input class="form-control mb-2" type="email" name="email" required>
        <label>Phone</label>
        <input class="form-control mb-2" name="phone" required>
        <label>Username</label>
        <input class="form-control mb-2" name="username" required>
        <label>Password</label>
        <input class="form-control mb-3" type="password" name="password" minlength="8" required>
        <button class="btn btn-primary" type="submit">Register</button>
        <a class="btn btn-secondary" href="index.php">Home</a>
    </form>
</div>
</body>
</html>
