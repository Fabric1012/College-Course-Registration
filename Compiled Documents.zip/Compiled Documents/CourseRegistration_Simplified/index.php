<!DOCTYPE html>
<html>
<head>
    <title>College Course Registration</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container text-center mt-5">
        <h1>College Course Registration</h1>
        <p>Welcome! Create an account or log in.</p>
        <a class="btn btn-primary" href="Registration.php">Register</a>
        <a class="btn btn-secondary" href="login.php">Login</a>
        <a class="btn btn-success" href="courses.php">My Classes</a>
    </div>
</body>
</html>
