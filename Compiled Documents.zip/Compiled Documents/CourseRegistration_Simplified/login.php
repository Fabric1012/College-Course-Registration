<?php
session_start();
require_once 'Database.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $database = new Database();
    $connection = $database->connect();
    $sql = 'SELECT id, password_hash FROM students WHERE username = ?';
    $statement = $connection->prepare($sql);
    $statement->bind_param('s', $username);
    $statement->execute();
    $student = $statement->get_result()->fetch_assoc();

    if ($student && password_verify($password, $student['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['student_id'] = $student['id'];
        header('Location: profile.php');
        exit;
    } else {
        $message = 'Wrong username or password.';
    }
    $statement->close();
    $connection->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-5" style="max-width: 450px;">
    <h1>Student Login</h1>
    <p><?php echo htmlspecialchars($message); ?></p>
    <form method="post">
        <label>Username</label>
        <input class="form-control mb-2" name="username" required>
        <label>Password</label>
        <input class="form-control mb-3" type="password" name="password" required>
        <button class="btn btn-primary">Login</button>
        <a class="btn btn-secondary" href="index.php">Home</a>
    </form>
</div>
</body>
</html>
