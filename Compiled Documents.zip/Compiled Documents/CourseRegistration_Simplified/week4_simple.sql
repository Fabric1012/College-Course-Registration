-- Import into phpMyAdmin. Keeps existing student accounts.
CREATE DATABASE IF NOT EXISTS course_registration_db;
USE course_registration_db;

CREATE TABLE IF NOT EXISTS courses (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(20) NOT NULL,
    title VARCHAR(100) NOT NULL,
    semester VARCHAR(20) NOT NULL,
    UNIQUE KEY unique_course (code, semester)
);

CREATE TABLE IF NOT EXISTS enrollments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id INT UNSIGNED NOT NULL,
    course_id INT UNSIGNED NOT NULL,
    UNIQUE KEY one_class_per_student (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

INSERT IGNORE INTO courses (code, title, semester) VALUES
('CST101', 'Introduction to Programming', 'Spring'),
('ENG101', 'English Composition', 'Spring'),
('MAT110', 'College Algebra', 'Spring'),
('CST210', 'Web Development', 'Summer'),
('BUS101', 'Introduction to Business', 'Summer'),
('CST220', 'Database Basics', 'Fall'),
('HIS101', 'US History', 'Fall'),
('CST230', 'Computer Networks', 'Fall');
