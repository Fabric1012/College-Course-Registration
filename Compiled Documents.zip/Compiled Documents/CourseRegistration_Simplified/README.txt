SIMPLE COLLEGE COURSE REGISTRATION - WEEK 3

1. Unzip the folder CourseRegistration.
2. Copy CourseRegistration to C:\xampp\htdocs\
3. In XAMPP start Apache and MySQL.
4. Open http://localhost/phpmyadmin/
5. Select Import, choose course_registration_db.sql, then click Go.
6. Open http://localhost/CourseRegistration/
7. Register a test student and log in.
8. Check course_registration_db > students in phpMyAdmin.

FILES
index.php = Home page
Registration.php = Student signup form and save code
login.php = Student login
Database.php = MySQL connection class
profile.php = Student profile
logout.php = Sign out
course_registration_db.sql = Creates database and students table

