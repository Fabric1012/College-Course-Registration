<?php
// Connect to the MySQL database.
class Database {
    public function connect() {
        $connection = new mysqli('localhost', 'root', '', 'course_registration_db');
        if ($connection->connect_error) {
            exit('Database connection failed. Start MySQL in XAMPP.');
        }
        $connection->set_charset('utf8mb4');
        return $connection;
    }
}
