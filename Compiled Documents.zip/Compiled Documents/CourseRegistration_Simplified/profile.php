<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}
require_once 'Database.php';
$database = new Database();
$connection = $database->connect();
$sql = 'SELECT student_id, first_name, last_name, email, phone, username FROM students WHERE id = ?';
$statement = $connection->prepare($sql);
$statement->bind_param('i', $_SESSION['student_id']);
$statement->execute();
$student = $statement->get_result()->fetch_assoc();
if (!$student) {
    header('Location: logout.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Profile</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-5">
    <h1>Student Profile</h1>
    <p>Name: <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></p>
    <p>Student ID: <?php echo htmlspecialchars($student['student_id']); ?></p>
    <p>Email: <?php echo htmlspecialchars($student['email']); ?></p>
    <p>Phone: <?php echo htmlspecialchars($student['phone']); ?></p>
    <p>Username: <?php echo htmlspecialchars($student['username']); ?></p>
    <a class="btn btn-primary" href="courses.php">My Classes</a>
    <a class="btn btn-danger" href="logout.php">Logout</a>
</div>
</body>
</html>
